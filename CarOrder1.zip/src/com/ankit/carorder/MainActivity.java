package com.ankit.carorder;

import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.ankit.carorder.dbmanager.datasource.CarColorDatasource;
import com.ankit.carorder.dbmanager.datasource.CarModelDatasource;
import com.ankit.carorder.dbmanager.datasource.ManufacturerDatasource;
import com.ankit.carorder.dbmanager.datasource.OrderDatasource;
import com.ankit.carorder.dbmanager.model.CarColor;
import com.ankit.carorder.dbmanager.model.Order;

public class MainActivity extends Activity {
	private static final String CAR_PREFS = "car_preference";
	private static final String PREFS_FIRST_TIME = "first_time";
	private static final int PENDING_ORDER = 0;
	private static final int PLACED_ORDER = 1;
	private CarColorDatasource colorDatasource;
	private OrderDatasource orderDatasource;
	private ManufacturerDatasource manuDatasource;
	private CarModelDatasource modelDatasource;
	private ArrayAdapter<Order> pendingAdapter;
	private ArrayAdapter<Order> placedAdapter;
	private List<Order> placedOrderValues;
	private List<Order> pendingOrderValues;
	private ListView pendingList;
	private ListView placedList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		Log.d("Click", "onCreate:start");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		colorDatasource = new CarColorDatasource(this);
		orderDatasource = new OrderDatasource(this);
		manuDatasource = new ManufacturerDatasource(this);
		modelDatasource = new CarModelDatasource(this);
		loadInitialData();
		refreshOrderLists();
		pendingList = (ListView) findViewById(R.id.pending_list);
		placedList = (ListView) findViewById(R.id.placed_list);
		pendingList.setAdapter(pendingAdapter);
		placedList.setAdapter(placedAdapter);
		Log.d("Click", "onCreate:end");
	}

	@Override
	protected void onResume() {
		Log.d("Click", "Onresume:start");
		refreshOrderLists();
		if (pendingAdapter != null) {
			pendingAdapter.notifyDataSetChanged();
		}
		if (placedAdapter != null) {
			placedAdapter.notifyDataSetChanged();
		}
		super.onResume();
		Log.d("Click", "Onresume:end");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);

		return true;
	}

	// @Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle item selection
		switch (item.getItemId()) {
		case R.id.action_order:
			Intent newOrderIntent = new Intent(this, NewOrder.class);
			startActivity(newOrderIntent);
			return true;
		case R.id.action_refresh:

			return true;
		default:
			return super.onOptionsItemSelected(item);

		}

	}

	void refreshOrderLists() {
		Log.d("Click", "refreshOrderLists:start");
		orderDatasource.open();
		pendingOrderValues = orderDatasource
				.getAllOrdersByStatus(PENDING_ORDER);
		placedOrderValues = orderDatasource.getAllOrdersByStatus(PLACED_ORDER);
		orderDatasource.close();
		pendingAdapter = new ArrayAdapter<Order>(this,
				android.R.layout.simple_list_item_1, pendingOrderValues);

		placedAdapter = new ArrayAdapter<Order>(this,
				android.R.layout.simple_list_item_1, placedOrderValues);

		if (pendingList != null)
			pendingList.setAdapter(pendingAdapter);
		if (placedList != null)
			placedList.setAdapter(placedAdapter);

		Log.d("Click", "refreshOrderLists:end" + placedOrderValues.size());
	}

	void loadInitialData() {
		SharedPreferences settings = this.getSharedPreferences(CAR_PREFS, 0);
		if (!settings.getBoolean(PREFS_FIRST_TIME, false)) {
			colorDatasource.open();
			colorDatasource.insertData();
			colorDatasource.close();
			manuDatasource.open();
			manuDatasource.insertData();
			manuDatasource.close();

			modelDatasource.open();
			modelDatasource.insertData();
			modelDatasource.close();

			SharedPreferences.Editor editor = settings.edit();
			editor.putBoolean(PREFS_FIRST_TIME, true);
			editor.commit();
		}
	}
}
